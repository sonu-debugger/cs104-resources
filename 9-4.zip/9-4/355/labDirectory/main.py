'''
    Let's go to casino
    Author: Saksham Rathi
'''
import sys
# Please write your code in this file.