#!/bin/bash

python3 script.py
