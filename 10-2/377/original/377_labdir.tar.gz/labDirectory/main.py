'''
    Distributions
'''

import numpy as np
from matplotlib import pyplot as plt

# Seeding for reproducibility


# sampling from each of the six distributions


# plotting histograms for each of the distributions
# plt.subplot(3,2,1)


# adjust the sub-plots to fit the titles and labels
plt.tight_layout()
# save the plot as plot.png
plt.savefig('plot.png')
